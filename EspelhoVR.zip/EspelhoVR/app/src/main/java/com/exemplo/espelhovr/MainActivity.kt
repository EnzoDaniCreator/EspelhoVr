package com.exemplo.espelhovr

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var switchVr: Switch
    private lateinit var seekAlpha: SeekBar
    private var pediuNotificacao = false

    private val pedirPermissoes =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                proximoPasso()
            } else {
                aviso("Sem permissão da câmera o app não funciona.")
            }
        }

    private val pedirOverlay =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) proximoPasso()
            else aviso("Ative \"Exibir sobre outros apps\" para continuar.")
        }

    private val pedirCaptura =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val dados = r.data
            if (r.resultCode == Activity.RESULT_OK && dados != null) {
                val i = Intent(this, OverlayService::class.java).apply {
                    putExtra(OverlayService.EXTRA_CODE, r.resultCode)
                    putExtra(OverlayService.EXTRA_DATA, dados)
                    putExtra(OverlayService.EXTRA_VR, switchVr.isChecked)
                    putExtra(OverlayService.EXTRA_ALPHA, seekAlpha.progress / 100f)
                }
                ContextCompat.startForegroundService(this, i)
                moveTaskToBack(true) // vai para o fundo; abra o app que quer espelhar
            } else {
                aviso("A captura de tela foi cancelada.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        switchVr = findViewById(R.id.switchVr)
        seekAlpha = findViewById(R.id.seekAlpha)
        findViewById<Button>(R.id.btnStart).setOnClickListener { proximoPasso() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    // Verifica uma permissão por vez e, quando tudo estiver ok, pede a captura de tela.
    private fun proximoPasso() {
        if (!Settings.canDrawOverlays(this)) {
            pedirOverlay.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val faltando = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            faltando += Manifest.permission.CAMERA
        }
        if (Build.VERSION.SDK_INT >= 33 && !pediuNotificacao &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            pediuNotificacao = true
            faltando += Manifest.permission.POST_NOTIFICATIONS
        }
        if (faltando.isNotEmpty()) {
            pedirPermissoes.launch(faltando.toTypedArray())
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        pedirCaptura.launch(mpm.createScreenCaptureIntent())
    }

    private fun aviso(texto: String) = Toast.makeText(this, texto, Toast.LENGTH_LONG).show()
}
