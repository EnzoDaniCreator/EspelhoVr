package com.exemplo.espelhovr

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.drawable.Icon
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/**
 * Serviço que desenha uma janela por cima de tudo (overlay) com:
 *  - a câmera ao fundo
 *  - o espelho da tela do app escolhido por cima (com opacidade ajustável)
 *  - no modo VR, duas cópias lado a lado (um quadro para cada olho)
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_VR = "vr"
        const val EXTRA_ALPHA = "alpha"
        const val ACTION_STOP = "com.exemplo.espelhovr.STOP"
        // 0.5 = metade da resolução (mais fluido). Use 1f para a imagem mais nítida.
        private const val ESCALA_ESPELHO = 0.5f
        private const val CANAL = "espelho_vr"
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var iniciado = false
    private var modoVr = false
    private var opacidade = 0.8f

    private var raiz: FrameLayout? = null
    private val viewsCamera = mutableListOf<TextureView>()
    private val viewsEspelho = mutableListOf<ImageView>()

    private var projecao: MediaProjection? = null
    private var callbackProjecao: MediaProjection.Callback? = null
    private var telaVirtual: VirtualDisplay? = null
    private var leitorImagem: ImageReader? = null
    private var bitmapEspelho: Bitmap? = null
    private var threadEspelho: HandlerThread? = null

    private var camera: CameraDevice? = null
    private var sessao: CameraCaptureSession? = null
    private var threadCamera: HandlerThread? = null
    private var handlerCamera: Handler? = null
    private var cameraIniciando = false
    private var tamanhoCamera = Size(1280, 720)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent == null || iniciado) return START_NOT_STICKY
        iniciado = true

        // 1) Notificação obrigatória de serviço em primeiro plano (precisa vir ANTES da projeção)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL, "Espelho VR", NotificationManager.IMPORTANCE_LOW)
        )
        val pararPi = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notificacao = Notification.Builder(this, CANAL)
            .setContentTitle("Espelho VR ativo")
            .setContentText("Toque em Parar para encerrar")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete), "Parar", pararPi
                ).build()
            )
            .build()
        startForeground(
            1, notificacao,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )

        // 2) Dados enviados pela tela principal
        val codigo = intent.getIntExtra(EXTRA_CODE, 0)
        val dados: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        modoVr = intent.getBooleanExtra(EXTRA_VR, false)
        opacidade = intent.getFloatExtra(EXTRA_ALPHA, 0.8f)
        if (dados == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // 3) Projeção de tela (o Android 14 exige registrar o callback antes de criar a tela virtual)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(codigo, dados)
        val cb = object : MediaProjection.Callback() {
            override fun onStop() {
                ui.post { stopSelf() }
            }
        }
        p.registerCallback(cb, ui)
        projecao = p
        callbackProjecao = cb

        montarJanela()
        iniciarEspelho(p)
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- janela

    private fun montarJanela() {
        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val olhos = if (modoVr) 2 else 1

        repeat(olhos) {
            val olho = FrameLayout(this)

            val cam = TextureView(this)
            cam.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = tentarAbrirCamera()
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            cam.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ -> ajustarCamera(v as TextureView) }

            val espelho = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                alpha = opacidade
            }

            olho.addView(cam, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            olho.addView(espelho, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            linha.addView(olho, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
            viewsCamera += cam
            viewsEspelho += espelho
        }

        val r = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(linha, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }
        raiz = r

        // NOT_TOUCHABLE: os toques passam para o app que está embaixo.
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(r, lp)
    }

    // ---------------------------------------------------------------- espelho da tela

    private fun iniciarEspelho(p: MediaProjection) {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)

        // Metade da resolução, em múltiplos de 16, para ficar fluido.
        val w = ((m.widthPixels * ESCALA_ESPELHO).toInt() / 16) * 16
        val h = ((m.heightPixels * ESCALA_ESPELHO).toInt() / 16) * 16

        val t = HandlerThread("espelho").also { it.start() }
        threadEspelho = t

        val leitor = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        leitor.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plano = img.planes[0]
                val padding = plano.rowStride - plano.pixelStride * img.width
                val larguraBmp = img.width + padding / plano.pixelStride
                var bmp = bitmapEspelho
                if (bmp == null || bmp.width != larguraBmp || bmp.height != img.height) {
                    bmp = Bitmap.createBitmap(larguraBmp, img.height, Bitmap.Config.ARGB_8888)
                    bitmapEspelho = bmp
                }
                bmp.copyPixelsFromBuffer(plano.buffer)
                val pronto = if (padding == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
                ui.post { viewsEspelho.forEach { it.setImageBitmap(pronto) } }
            } finally {
                img.close()
            }
        }, Handler(t.looper))
        leitorImagem = leitor

        telaVirtual = p.createVirtualDisplay(
            "espelho", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            leitor.surface, null, null
        )
    }

    // ---------------------------------------------------------------- câmera

    private fun tentarAbrirCamera() {
        if (cameraIniciando) return
        if (viewsCamera.isEmpty() || viewsCamera.any { !it.isAvailable }) return
        cameraIniciando = true
        abrirCamera()
    }

    @SuppressLint("MissingPermission")
    private fun abrirCamera() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val t = HandlerThread("camera").also { it.start() }
        threadCamera = t
        handlerCamera = Handler(t.looper)

        val cm = getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        } ?: cm.cameraIdList.firstOrNull() ?: return

        val mapa = cm.getCameraCharacteristics(id)
            .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        tamanhoCamera = mapa?.getOutputSizes(SurfaceTexture::class.java)
            ?.filter { it.width <= 1280 && it.height <= 720 }
            ?.maxByOrNull { it.width * it.height }
            ?: Size(640, 480)

        cm.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(c: CameraDevice) {
                camera = c
                criarSessao(c)
            }

            override fun onDisconnected(c: CameraDevice) {
                c.close()
                camera = null
            }

            override fun onError(c: CameraDevice, erro: Int) {
                c.close()
                camera = null
            }
        }, handlerCamera)
    }

    @Suppress("DEPRECATION")
    private fun criarSessao(c: CameraDevice) {
        val superficies = viewsCamera.map { v ->
            val st = v.surfaceTexture!!
            st.setDefaultBufferSize(tamanhoCamera.width, tamanhoCamera.height)
            Surface(st)
        }
        val pedido = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            superficies.forEach { addTarget(it) }
            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        }
        c.createCaptureSession(superficies, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                sessao = s
                s.setRepeatingRequest(pedido.build(), null, handlerCamera)
                ui.post { viewsCamera.forEach { ajustarCamera(it) } }
            }

            override fun onConfigureFailed(s: CameraCaptureSession) {}
        }, handlerCamera)
    }

    // Corrige rotação/proporção da câmera conforme a orientação da tela.
    private fun ajustarCamera(view: TextureView) {
        val w = view.width.toFloat()
        val h = view.height.toFloat()
        if (w == 0f || h == 0f) return
        @Suppress("DEPRECATION") val rotacao = wm.defaultDisplay.rotation
        val matriz = Matrix()
        val rectView = RectF(0f, 0f, w, h)
        val rectBuffer = RectF(0f, 0f, tamanhoCamera.height.toFloat(), tamanhoCamera.width.toFloat())
        val cx = rectView.centerX()
        val cy = rectView.centerY()
        if (rotacao == Surface.ROTATION_90 || rotacao == Surface.ROTATION_270) {
            rectBuffer.offset(cx - rectBuffer.centerX(), cy - rectBuffer.centerY())
            matriz.setRectToRect(rectView, rectBuffer, Matrix.ScaleToFit.FILL)
            val escala = maxOf(h / tamanhoCamera.height, w / tamanhoCamera.width)
            matriz.postScale(escala, escala, cx, cy)
            matriz.postRotate(90f * (rotacao - 2), cx, cy)
        } else if (rotacao == Surface.ROTATION_180) {
            matriz.postRotate(180f, cx, cy)
        }
        view.setTransform(matriz)
    }

    // ---------------------------------------------------------------- encerramento

    override fun onDestroy() {
        iniciado = false
        try { sessao?.close() } catch (_: Exception) {}
        try { camera?.close() } catch (_: Exception) {}
        try { telaVirtual?.release() } catch (_: Exception) {}
        try { leitorImagem?.close() } catch (_: Exception) {}
        callbackProjecao?.let { projecao?.unregisterCallback(it) }
        try { projecao?.stop() } catch (_: Exception) {}
        raiz?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        threadCamera?.quitSafely()
        threadEspelho?.quitSafely()
        super.onDestroy()
    }
}
